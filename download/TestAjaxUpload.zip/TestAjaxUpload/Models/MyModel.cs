﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TestAjaxUpload
{
    public class MyModel
    {
        public HttpPostedFileBase MyFile { get; set; }
    }
}