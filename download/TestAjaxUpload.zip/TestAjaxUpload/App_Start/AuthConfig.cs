﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TestAjaxUpload
{
    public static class AuthConfig
    {
        public static void RegisterAuth()
        {

        }
    }
}
